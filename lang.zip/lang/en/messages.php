<?php

return [
            'success'       =>  'Successfully fectched',
        ];
